<?php

class SensitiveException extends Exception {}
