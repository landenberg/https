<?php

use Twig\Markup;

class_exists('Twig\Markup');

if (\false) {
    class Twig_Markup extends Markup
    {
    }
}
