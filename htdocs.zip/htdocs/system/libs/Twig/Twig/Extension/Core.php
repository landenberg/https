<?php

use Twig\Extension\CoreExtension;

class_exists('Twig\Extension\CoreExtension');

if (\false) {
    class Twig_Extension_Core extends CoreExtension
    {
    }
}
