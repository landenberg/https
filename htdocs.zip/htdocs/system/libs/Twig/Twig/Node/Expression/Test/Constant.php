<?php

use Twig\Node\Expression\Test\ConstantTest;

class_exists('Twig\Node\Expression\Test\ConstantTest');

if (\false) {
    class Twig_Node_Expression_Test_Constant extends ConstantTest
    {
    }
}
